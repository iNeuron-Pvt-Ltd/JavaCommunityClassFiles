package com.ineuron.Lecture2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class JBasicPart2 {
    public static void main(String[] args) throws IOException {
//
////    you want to say Hello if someone says Hello
////    otherwise you will say Namaste
//// operators ==, >=, >, <, <=, !=
//        int a = 2;
//        int b = 2;
////        char operator = '+';
//// Nested if else
////
//
//        if (a > b)
//            System.out.println("a is greater than b");
//        else if (a==b)
//            System.out.println("a is equal to b");
//        else
//            System.out.println("a is greater than b");


        /**
         * Build a basic calculator
         */
//        Take two numbers as input from user
//        Then take input as what operation they want to do on those numbers('+', '-', '*', '/')
//        perform that operation

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter 1st Number : ");
        int num1 = Integer.parseInt(br.readLine());
        System.out.println("Enter 2nd Number : ");
        int num2 = Integer.parseInt(br.readLine());
        System.out.println("Enter Operator : ");
        String operator = br.readLine();

        int result;

        if (operator.equals("+"))
            result = num1 + num2;
        else if (operator.equals("-"))
            result = num1 - num2;
        else if (operator.equals("*"))
            result = num1 * num2;
        else
            result = num1/num2;

        System.out.println("Result : " + result);


    }
}
