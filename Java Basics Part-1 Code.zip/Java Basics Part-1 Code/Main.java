package com.ineuron;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

public class Main {
// Build an Q n A application

    public static void main(String[] args) throws IOException {

//        Ask Questions : \n23\n
//        Scanner sc = new Scanner(System.in);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("What is your Name : ");
        String name = br.readLine();
        System.out.println("What is your age : ");
//        sc.nextInt()
        int age = Integer.parseInt(br.readLine()); //23
        System.out.println("Are you married : ");
        boolean marriedStatus = Boolean.parseBoolean(br.readLine());

        System.out.println("Where do you live : ");
        // One way to avoid skip scanner issue
//        sc.nextLine();
        String city = br.readLine();
        System.out.println("Thankyou !!!");

//        Print the whole Q n A

        System.out.println("I found My 1st Friend");
        System.out.println("His/Her name is " + name);
        System.out.println("He/She is " + age + " years old");
        System.out.println("He/She is married : " + marriedStatus);
        System.out.println("He/she lives in " + city);

        System.out.println("Insert Boolean value : ");
        boolean bool = Boolean.parseBoolean("TRUE");
        System.out.println(bool);

    }
}
